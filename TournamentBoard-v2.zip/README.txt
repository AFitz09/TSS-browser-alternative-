Tournament Board - unofficial War Thunder tournament tracker
===========================================================

Nothing else needs to be installed: it only uses Windows PowerShell and Microsoft Edge,
which come with Windows 10 and 11.

To install:
  1. Extract this zip first (right-click > Extract All). Don't run it from inside the zip.
  2. Double-click TournamentBoard-Setup.exe.
  3. If Windows says "Windows protected your PC", click "More info" > "Run anyway".
     (The file isn't code-signed, so Windows warns about it.)
  4. Pick your options and click Install.

Tournament Board then opens in its own window and is in the Start Menu.
It shows the current tournaments from tss.warthunder.com and refreshes every 10 minutes.
Closing the window closes the app. "Open on TSS" links open in your normal browser.

To uninstall: Settings > Apps > Installed apps > Tournament Board > Uninstall.

Not affiliated with or endorsed by Gaijin Entertainment.
